###
###

.pkgname <- "BSgenome.Mmusculus.SingleMoleculeGenomicsIO"

.seqnames <- NULL

.circ_seqs <- "chrM"

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Mus musculus",
        common_name="Mouse",
        genome="GRCm38",
        provider="SingleMoleculeGneomicsIO",
        release_date="2025-12-02",
        source_url="-- information not available --",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "BSgenome.Mmusculus.SingleMoleculeGenomicsIO"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

